'use strict';

/**
 * Firefox Scripts - Auto-Updater Module (ESM)
 *
 * Runs inside the browser (loaded by BootstrapLoader.js / userChrome.js) and
 * keeps the three published packages up to date:
 *
 * - fx-folder (config.js, defaults/pref/config-prefs.js) -> browser dir (GreD)
 * - utils (chrome scripts) -> profile chrome/utils
 * - updater-ui (the update tab itself) -> profile chrome/utils/updater/ui
 *
 * Update detection reuses the installer's hash-based logic
 * (docs/status-logic.md): fetch the manifest from the gh-pages branch, hash the
 * locally installed file set with the manifest's canonical `files` list, and
 * compare. No versionInfo.json dependency.
 *
 * This module is the ONLY updater code that ships inside utils.zip: it checks
 * for updates and downloads/extracts the updater-ui package. Everything the tab
 * does (rendering, installing utils/config, restarting) lives in updater-ui.zip
 * (chrome://firefox-scripts/content/ui/updater.html). If a package cannot be
 * downloaded, the check fails silently — there is no error UI to show, so the
 * tab is simply not opened. One exception (ADR 0026): a dev-channel install
 * whose own manifest is unreachable falls back to the stable channel's manifest
 * (generated STABLE_* URLs) and auto-migrates; see fetchOwnManifestOrFallback()
 * below. --local snapshots keep the silent exit.
 *
 * Notification = a new tab, shown at most once per day (pref
 * extensions.firefox-scripts.lastUpdateTabShown). The user-decision date
 * (extensions.firefox-scripts.lastScriptsCheckDate) is recorded ONLY by the tab
 * UI on real interaction — installing, skipping, "Remind me Tomorrow", or a
 * restart — never when the tab merely opens. Per-package skips are stored as
 * extensions.firefox-scripts.skippedHash.<package> = remote hash.
 */

// URL/path configuration — generated from config/installer.conf at publish
// time (tools/publish/generateUpdaterConfig.mjs).  Single source of truth.
const {CONFIG} = ChromeUtils.importESModule(
  'chrome://firefox-scripts/content/updater-config.sys.mjs'
);

// Test/local override prefs: a string pref
// extensions.firefox-scripts.override.<KEY> (HASHES_URL, ZIP_BASE_URL,
// UI_BASE_URL, HELPER_BASE_URL) wins over the generated CONFIG value.  This
// lets tests point the updater at any local snapshot (e.g. one built on
// another OS) WITHOUT touching the config file — it ships inside utils.zip and
// is part of the hashed file set, so rewriting it would flip the package hash
// and break the staleness check.
const PREF_OVERRIDE_PREFIX = 'extensions.firefox-scripts.override.';

function configValue(key) {
  try {
    const override = Services.prefs.getStringPref(PREF_OVERRIDE_PREFIX + key, '');
    if (override) {
      return override;
    }
  } catch (_) {
    // unreadable pref → fall back to the generated CONFIG value
  }
  return CONFIG[key];
}

/**
 * Stable-channel URL (the STABLE_* keys exist in dev-build configs only; a
 * stable build's own URLs are its channel, so its empty STABLE_* values fall
 * back to the own key). Like configValue, the test-local override pref wins —
 * the e2e harness points the fallback at its local snapshot server the same way
 * it points the own-channel URLs. Real users never set override prefs, so
 * behavior is unchanged for them.
 */
function stableConfigValue(key) {
  const stable = configValue(`STABLE_${key}`);
  return stable || configValue(key);
}

/**
 * Resolved against the ACTIVE channel, so a dev build that migrated to stable
 * keeps resolving stable URLs (the channel functions read the same state
 * fetchOwnManifestOrFallback writes).
 */
function channelValue(key) {
  // A dev install on its own test channel (and every --local snapshot)
  // resolves its own baked URLs; anything on the stable channel resolves the
  // STABLE_* URLs (a migrated dev build) or the own values (a stable build,
  // whose STABLE_* keys are empty).
  if (CONFIG.IS_LOCAL || activeChannel() === CHANNEL_DEV) {
    return configValue(key);
  }
  return stableConfigValue(key);
}

export function getHashesUrl() {
  return channelValue('HASHES_URL');
}

export function getZipBaseUrl() {
  return channelValue('ZIP_BASE_URL');
}

/**
 * Base URL of the updater tab UI package (updater-ui.zip). It is published next
 * to the hash manifest (gh-pages / the dev-build branch / the local snapshot
 * dir) and is never a release asset (upload.mjs), so it must come from the
 * manifest's own host — not ZIP_BASE_URL, which is the release URL and has no
 * updater-ui zip in prod (issue #102).
 */
/**
 * Base URL of the updater tab UI package (updater-ui.zip) on the active
 * channel.
 */
export function getUiBaseUrl() {
  // Fall back to ZIP_BASE_URL only when the paired generated config predates
  // UI_BASE_URL (never true for zips built by the same publish run) — it keeps
  // the pre-#102 behavior instead of building an invalid URL.
  // Channel-aware: on the dev channel this is UI_BASE_URL (or the pre-#102
  // ZIP_BASE_URL fallback); on stable it resolves from the STABLE_* pair.
  return channelValue('UI_BASE_URL') || getZipBaseUrl();
}

export function getHelperBaseUrl() {
  return channelValue('HELPER_BASE_URL');
}

const {Downloads} = ChromeUtils.importESModule('resource://gre/modules/Downloads.sys.mjs');

// The actual update tab (updater-ui.zip) — a privileged chrome:// page.
const UPDATER_UI_URI = 'chrome://firefox-scripts/content/ui/updater.html';
const CHECK_INTERVAL_MS = 24 * 60 * 60 * 1000; // once per day
const MANIFEST_TIMEOUT_MS = 15000; // dead manifest host -> failed check, not a hang

const PREF_LAST_CHECK = 'extensions.firefox-scripts.lastScriptsCheckDate';
const PREF_LAST_SHOWN = 'extensions.firefox-scripts.lastUpdateTabShown';
const PREF_SKIP_PREFIX = 'extensions.firefox-scripts.skippedHash.';

/* ---------------- publish channels (ADR 0026) ----------------
 *
 * A dev install's generated config points exclusively at its dev-build branch.
 * When that branch is deleted the install would be stranded forever, so the
 * generated dev config carries the stable channel's URLs (STABLE_* keys) and
 * the daily check falls back to the stable manifest when the test channel's
 * own manifest is unreachable. Installing stable rewrites the installed
 * updater-config.sys.mjs with prod URLs — the channel migrates itself; the
 * persisted pref records it.
 *
 * --local snapshots keep the silent exit (ephemeral by design, ADR 0026):
 * their initial channel is 'local' regardless of the build mode.
 */
const PREF_ACTIVE_CHANNEL = 'extensions.firefox-scripts.activeChannel';
// The dev-build branch identity a migration belonged to (`CONFIG.DEV_BRANCH`).
// A stored stable channel is honored only while this matches the running
// build — otherwise a different dev build would inherit the migration and be
// dragged to stable (its own manifest may still be alive).
const PREF_ACTIVE_CHANNEL_BUILD = 'extensions.firefox-scripts.activeChannelBuild';
const CHANNEL_STABLE = 'stable';
const CHANNEL_DEV = 'dev';
const CHANNEL_LOCAL = 'local';

let gActiveChannel = null;
// True only for the session in which the daily check actually migrated from
// the dev channel to stable — the updater tab turns this into its banner.
let gMigratedFromDev = false;

function initialChannel() {
  // Local snapshots never channel: a harness profile that once held a real
  // install must not inherit its stored channel.
  if (CONFIG.IS_LOCAL) {
    return CHANNEL_LOCAL;
  }
  try {
    if (Services.prefs.getPrefType(PREF_ACTIVE_CHANNEL) === Services.prefs.PREF_STRING) {
      const stored = Services.prefs.getCharPref(PREF_ACTIVE_CHANNEL, '');
      if (stored) {
        // A persisted stable channel is honored only when it belongs to THIS
        // dev build. A different dev build evaluates its own IS_DEV branch:
        // its manifest may still be alive, and if it later dies, the fallback
        // records its own migration.
        if (stored === CHANNEL_STABLE) {
          try {
            const build = Services.prefs.getCharPref(PREF_ACTIVE_CHANNEL_BUILD, '');
            if (build && build === CONFIG.DEV_BRANCH) {
              return CHANNEL_STABLE;
            }
          } catch (_) {
            // unreadable build pref → fall through to build-mode derivation
          }
          return CONFIG.IS_DEV ? CHANNEL_DEV : CHANNEL_STABLE;
        }
        return stored;
      }
    }
  } catch (_) {
    // unreadable pref store → derive from the build mode
  }
  return CONFIG.IS_DEV ? CHANNEL_DEV : CHANNEL_STABLE;
}

function activeChannel() {
  if (gActiveChannel === null) {
    gActiveChannel = initialChannel();
  }
  return gActiveChannel;
}

function setActiveChannel(channel) {
  gActiveChannel = channel;
  try {
    Services.prefs.setCharPref(PREF_ACTIVE_CHANNEL, channel);
    if (channel === CHANNEL_STABLE && CONFIG.IS_DEV) {
      // Record which dev build the migration belonged to (see
      // initialChannel — a different dev build must not inherit it).
      Services.prefs.setCharPref(PREF_ACTIVE_CHANNEL_BUILD, CONFIG.DEV_BRANCH || '');
    }
  } catch (_) {
    // A read-only pref store cannot persist the migration; the session flag
    // still drives the tab banner for this run.
  }
}

/**
 * Channel state for the updater tab: the channel URLs currently resolve
 * against, and whether THIS session's check migrated from the dev channel (the
 * tab shows the one-time migration banner from it).
 */
export function getChannelState() {
  return {channel: activeChannel(), migratedFromDev: gMigratedFromDev};
}

/**
 * Asset-name suffix for the active channel ('' stable / '-dev' dev). Resolved
 * at call time — a dev install that migrated to stable must fetch utils.zip,
 * not utils-dev.zip, even though its baked CONFIG.ASSET_SUFFIX is still '-dev'.
 * Local snapshots keep their build-mode suffix (the harness snapshot names
 * carry it; they never fall back).
 */
export function getAssetSuffix() {
  if (CONFIG.IS_LOCAL || activeChannel() === CHANNEL_DEV) {
    return CONFIG.ASSET_SUFFIX || '';
  }
  return '';
}

let gInitialized = false;
let gWindow = null;

/**
 * Initialize the updater. Called per browser window on startup by
 * BootstrapLoader.js / userChrome.js; idempotent so double-init is harmless.
 *
 * @param {Window} win - the browser window
 */
export function initScriptsUpdater(win) {
  if (gInitialized) {
    return;
  }
  gInitialized = true;

  gWindow = win;

  // Check immediately (gated by the daily prefs), then once per day.
  checkForUpdates();
  setInterval(checkForUpdates, CHECK_INTERVAL_MS);
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

/**
 * Daily check: fetch the manifest, compute local hashes, keep the updater UI
 * current, and open the update tab when utils or fx-folder needs an update.
 *
 * Two independent daily prefs gate this:
 *
 * - PREF_LAST_CHECK (lastScriptsCheckDate) is set ONLY by the tab UI when the
 *   user makes a decision (installs / skips / reminds / restarts). A tab the
 *   user merely closed — or a manual browser restart with the tab left open —
 *   records nothing, so the pending update resurfaces instead of being marked
 *   as "checked".
 * - PREF_LAST_SHOWN is set here when the tab is opened, so an ignored tab does
 *   not re-open every few minutes within the same day.
 */
async function checkForUpdates() {
  const win = gWindow;
  if (!win || win.closed) {
    return;
  }

  const today = todayStr();
  if (Services.prefs.getCharPref(PREF_LAST_CHECK, '') === today) {
    return;
  }
  if (Services.prefs.getCharPref(PREF_LAST_SHOWN, '') === today) {
    return;
  }

  const scriptsInfo = await checkScriptsUpdateNeeded();

  // The tab opens only when utils or fx-folder needs attention; a pure
  // updater-ui change never disturbs the user.
  const updateNeeded = scriptsInfo.fxFolder.updateNeeded || scriptsInfo.utils.updateNeeded;
  if (!updateNeeded) {
    return;
  }

  // Keep the tab UI itself current before it opens (silent self-update). If
  // updater-ui.zip cannot be fetched and no UI is installed, there is nothing
  // useful to open — exit quietly instead of showing a broken tab.
  if (!(await ensureUpdaterUi(scriptsInfo.updaterUi))) {
    return;
  }

  const b = win.gBrowser;
  if (!b) {
    return;
  }

  // An updater tab may already be open (e.g. restored from a session): keep a
  // single instance.  Pending session-restore tabs expose the target via
  // initialURI before they finish loading.
  for (const tab of b.tabs) {
    if (
      tab.linkedBrowser?.currentURI?.spec === UPDATER_UI_URI ||
      tab.linkedBrowser?.initialURI === UPDATER_UI_URI
    ) {
      return;
    }
  }

  // Remember the tab was SHOWN today (not that the user decided).  The check
  // re-runs on the next browser start after a manual restart with the tab
  // left open: the restored tab re-checks in updater.js instead of showing a
  // stale "All packages are up to date.".
  Services.prefs.setCharPref(PREF_LAST_SHOWN, today);

  const tab = b.addTrustedTab(UPDATER_UI_URI);
  tab._scriptsUpdateTab = true;
  tab.loadOnStartup = true;
  b.selectedTab = tab;
}

/**
 * Race a promise against a deadline: rejects with an Error once `ms` elapses
 * without the promise settling. Uses an nsITimer and no window-dependent
 * globals, so it is safe in this module's (non-window) global.
 *
 * @param {Promise} promise - the operation to bound
 * @param {number} ms - deadline in milliseconds
 * @returns {Promise<any>} resolves/rejects with the promise's outcome
 */
function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = Cc['@mozilla.org/timer;1'].createInstance(Ci.nsITimer);
    timer.initWithCallback(
      () => reject(new Error(`operation timed out after ${ms}ms`)),
      ms,
      Ci.nsITimer.TYPE_ONE_SHOT
    );
    promise.then(
      value => {
        timer.cancel();
        resolve(value);
      },
      error => {
        timer.cancel();
        reject(error);
      }
    );
  });
}

/**
 * The directory fx-folder (config.js, defaults/pref/config-prefs.js) lives in.
 * Ordinary installs keep it in GreD — the app dir next to the binary.
 * Snap-packaged Firefox is different: Services GreD is the read-only
 * /snap/<name>/<rev>/... app mount, while the browser reads its autoconfig from
 * /etc/firefox on the host (where the install docs tell snap users to place
 * config.js). Hashing or copying against /snap/... can never match or write —
 * it left fx-folder permanently "Update Available" on the snap E2E leg (#55) —
 * so map snap installs to /etc/firefox.
 *
 * @returns {string}
 */
export function fxFolderDir() {
  const exePath = Services.dirsvc.get('XREExeF', Ci.nsIFile).path;
  if (exePath.includes('/snap/')) {
    return '/etc/firefox';
  }
  return Services.dirsvc.get('GreD', Ci.nsIFile).path;
}

/**
 * Fetch the hash manifest and compare per-package local hashes against it.
 *
 * Dead-test-channel fallback (ADR 0026): when the active dev channel's own
 * manifest is unreachable (its dev-build branch was deleted), fetch the stable
 * channel's manifest from the generated STABLE_* URLs and run the same hash
 * comparison against it — one attempt, then the normal silent exit. The
 * migration is recorded (channel pref + session flag) only after the stable
 * manifest is actually in hand; if stable is also unreachable the install stays
 * on the dev channel and the check fails silently as before. --local snapshots
 * never fall back (ephemeral by design).
 *
 * @returns {Promise<{fxFolder: Object; utils: Object; updaterUi: Object}>}
 */
export async function checkScriptsUpdateNeeded() {
  const result = {
    fxFolder: {updateNeeded: false, date: '', remoteHash: '', files: []},
    utils: {updateNeeded: false, date: '', remoteHash: '', files: []},
    updaterUi: {updateNeeded: false, date: '', remoteHash: '', files: []},
  };

  const manifestText = await fetchOwnManifestOrFallback();
  if (manifestText === null) {
    return result;
  }

  try {
    const remoteInfo = JSON.parse(manifestText);

    const profileDir = Services.dirsvc.get('ProfD', Ci.nsIFile).path;
    const dirs = {
      'fx-folder': fxFolderDir(),
      'utils': profileDir + '/chrome/utils',
      'updater-ui': profileDir + '/chrome/utils/updater/ui',
    };
    const keys = [
      ['fxFolder', 'fx-folder'],
      ['utils', 'utils'],
      ['updaterUi', 'updater-ui'],
    ];

    for (const [resultKey, pkgKey] of keys) {
      const remote = remoteInfo[pkgKey];
      if (!remote || !Array.isArray(remote.files) || !remote.hash) {
        continue;
      }
      const target = result[resultKey];
      target.date = remote.date || '';
      target.remoteHash = remote.hash;
      target.files = remote.files;

      const localHash = computeFilesHash(remote.files, dirs[pkgKey]);
      const hashMismatch = localHash !== remote.hash;

      // updater-ui is self-updating and has no user-facing skip toggle.
      if (pkgKey === 'updater-ui') {
        target.updateNeeded = hashMismatch;
        continue;
      }

      // Reset the skip pref when the remote hash changed or local files
      // already match.
      const skipHash = Services.prefs.getCharPref(PREF_SKIP_PREFIX + pkgKey, '');
      if (skipHash && (skipHash !== remote.hash || !hashMismatch)) {
        Services.prefs.clearUserPref(PREF_SKIP_PREFIX + pkgKey);
      }

      target.updateNeeded = hashMismatch && skipHash !== remote.hash;
    }

    return result;
  } catch (e) {
    console.error('Firefox Scripts: update check failed', e);
    return result;
  }
}

/**
 * Fetch the active channel's manifest; on failure, attempt the dead-test-
 * channel fallback to stable (ADR 0026). --local snapshots never fall back.
 *
 * @returns {Promise<string | null>} manifest JSON text, or null when both the
 *   own channel and (where applicable) the fallback are unreachable
 */
async function fetchOwnManifestOrFallback() {
  const url = getHashesUrl();
  try {
    // Never hang on a dead/stalled manifest host: the daily check must fail
    // fast and leave the tab closed rather than spin.
    return await withTimeout(fetchText(url), MANIFEST_TIMEOUT_MS);
  } catch (e) {
    console.error('Firefox Scripts: manifest fetch failed', e);
  }

  // Own manifest unreachable. Only a dev-channel install may fall back, and
  // only when its generated config actually carries the stable URLs.
  if (CONFIG.IS_LOCAL || activeChannel() !== CHANNEL_DEV) {
    return null;
  }
  if (!CONFIG.STABLE_HASHES_URL) {
    return null; // pre-0026 dev build: no stable URLs baked in, silent exit
  }
  // Resolve through stableConfigValue so the harness override prefs steer the
  // fallback too (same mechanism as every other URL getter). The baked
  // CONFIG.STABLE_HASHES_URL above stays the presence check: a pre-0026 build
  // has no key at all, while the resolved value would just fall back to the
  // (dead) own URL.
  const stableHashesUrl = stableConfigValue('HASHES_URL');
  if (!stableHashesUrl) {
    return null;
  }

  console.warn(
    'Firefox Scripts: dev channel manifest unreachable — falling back to the stable channel'
  );
  try {
    const stableText = await withTimeout(fetchText(stableHashesUrl), MANIFEST_TIMEOUT_MS);
    // Migration recorded only when stable answered: from here the URLs resolve
    // against stable and the updater tab shows the migration banner.
    setActiveChannel(CHANNEL_STABLE);
    gMigratedFromDev = true;
    console.warn('Firefox Scripts: dev channel is gone — migrated to the stable channel');
    return stableText;
  } catch (stableError) {
    console.error('Firefox Scripts: stable-channel fallback also failed', stableError);
    return null;
  }
}

/**
 * Keep the updater UI package current. When the installed updater/ui/ files do
 * not hash to the manifest's updater-ui entry, download updater-ui.zip, verify
 * it, and swap it in. Silent and idempotent.
 *
 * @param {Object} info - the manifest's updater-ui entry ({files, hash})
 * @returns {Promise<boolean>} true when the UI is usable afterwards
 */
export async function ensureUpdaterUi(info) {
  const uiDir = PathUtils.join(PathUtils.profileDir, 'chrome', 'utils', 'updater', 'ui');

  // A manifest without an updater-ui entry predates this package: keep whatever
  // is already installed (the UI is still usable for utils/config updates).
  if (!info || !Array.isArray(info.files) || !info.remoteHash) {
    return IOUtils.exists(PathUtils.join(uiDir, 'updater.html'));
  }

  if (computeFilesHash(info.files, uiDir) === info.remoteHash) {
    return true; // already current
  }

  const tmpDir = PathUtils.join(PathUtils.tempDir, `fxs-updater-ui-${Date.now()}`);
  try {
    const zipUrl = `${getUiBaseUrl()}/updater-ui${getAssetSuffix()}.zip`;
    const zipPath = PathUtils.join(tmpDir, 'updater-ui.zip');
    await Downloads.fetch(zipUrl, zipPath);

    // Verify the manifest hash BEFORE extracting anything: a failed check must
    // not leave a single file behind (and a tampered archive must never get
    // its entries written, even inside the temp dir).  computeZipFilesHash
    // reads the zip entries straight from the archive.
    if ((await computeZipFilesHash(info.files, zipPath)) !== info.remoteHash) {
      console.error(
        'Firefox Scripts: downloaded updater-ui.zip failed hash verification; keeping the current UI'
      );
      return false;
    }

    const extractDir = PathUtils.join(tmpDir, 'extracted');
    const baseDir = await extractZipFlatten(zipPath, extractDir);

    await copyFileList(info.files, baseDir, uiDir);
    // chrome://firefox-scripts/content/ui/* is served from disk per load, but
    // invalidate any chrome caches so navs pick up the swapped files at once.
    Services.obs.notifyObservers(null, 'chrome-flush-caches', null);
    return true;
  } catch (e) {
    // Missing/stale remote package: nothing the user can act on — fall back to
    // whatever UI is already installed (if any) and never throw.
    console.error('Firefox Scripts: updater-ui install failed', e);
    return IOUtils.exists(PathUtils.join(uiDir, 'updater.html'));
  } finally {
    try {
      await IOUtils.remove(tmpDir, {recursive: true, ignoreAbsent: true});
    } catch (e) {
      console.warn('Firefox Scripts: updater-ui temp cleanup failed', e);
    }
  }
}

/**
 * Privileged, CSP-bypassing fetch. The updater runs in chrome:// documents and
 * a module without a window; plain fetch() there is subject to Firefox's
 * default CSP for chrome pages (connect-src), which blocks the
 * http://localhost:<port> URLs baked into --local builds. Opening a channel
 * with the system principal bypasses that CSP and CORS.
 *
 * @param {string} url
 * @returns {Promise<Uint8Array>}
 */
export function fetchBytes(url) {
  return new Promise((resolve, reject) => {
    let channel;
    try {
      channel = Services.io.newChannelFromURI(
        Services.io.newURI(url),
        null,
        Services.scriptSecurityManager.getSystemPrincipal(),
        null,
        Ci.nsILoadInfo.SEC_ALLOW_CROSS_ORIGIN_SEC_CONTEXT_IS_NULL,
        Ci.nsIContentPolicy.TYPE_OTHER
      );
    } catch (e) {
      reject(e);
      return;
    }

    const chunks = [];
    const binary = Cc['@mozilla.org/binaryinputstream;1'].createInstance(Ci.nsIBinaryInputStream);

    const listener = {
      QueryInterface: ChromeUtils.generateQI(['nsIStreamListener', 'nsIRequestObserver']),
      onStartRequest() {},
      onDataAvailable(request, stream, offset, count) {
        binary.setInputStream(stream);
        chunks.push(binary.readByteArray(count));
      },
      onStopRequest(request, status) {
        // nsresult success codes have bit 31 clear (Components.isSuccessCode).
        if (status & 0x80000000) {
          reject(new Error(`Fetch failed (0x${status.toString(16)}): ${url}`));
          return;
        }
        // HTTP 4xx/5xx complete the channel successfully but are still
        // failures.
        let httpStatus = 0;
        try {
          httpStatus = request.QueryInterface(Ci.nsIHttpChannel).responseStatus;
        } catch {
          // non-HTTP channel (file:, data:, ...) — nothing to check
        }
        if (httpStatus >= 400) {
          const httpError = new Error(`HTTP ${httpStatus}: ${url}`);
          httpError.httpStatus = httpStatus;
          reject(httpError);
          return;
        }
        let total = 0;
        for (const c of chunks) {
          total += c.length;
        }
        const out = new Uint8Array(total);
        let off = 0;
        for (const c of chunks) {
          out.set(c, off);
          off += c.length;
        }
        resolve(out);
      },
    };

    channel.asyncOpen(listener);
  });
}

/** Privileged text fetch (UTF-8). */
export async function fetchText(url) {
  return new TextDecoder('utf-8').decode(await fetchBytes(url));
}

/**
 * Compute the SHA-256 over a file set, matching compute_directory_sha256() in
 * installer/src/detect_browser.c: for each relative path (sorted
 * case-insensitively): hash(rel_path + "\n") if the file exists:
 * hash(file_bytes) A listed-but-missing file contributes only path + "\n"
 * (empty content).
 *
 * @param {string[]} files - canonical relative paths (manifest `files` list)
 * @param {string} baseDir - absolute directory containing the files
 * @returns {string} hex digest
 */
export function computeFilesHash(files, baseDir) {
  const sorted = [...files].sort((a, b) => a.localeCompare(b));
  const nativeBase = Services.appinfo.OS === 'WINNT' ? baseDir.replace(/\//g, '\\') : baseDir;

  const baseFile = Cc['@mozilla.org/file/local;1'].createInstance(Ci.nsIFile);
  baseFile.initWithPath(nativeBase);

  const hasher = Cc['@mozilla.org/security/hash;1'].createInstance(Ci.nsICryptoHash);
  hasher.init(Ci.nsICryptoHash.SHA256);

  const encoder = new TextEncoder();
  const binStream = Cc['@mozilla.org/binaryinputstream;1'].createInstance(Ci.nsIBinaryInputStream);

  for (const relative of sorted) {
    const pathBytes = encoder.encode(relative + '\n');
    hasher.update(pathBytes, pathBytes.length);

    const file = baseFile.clone();
    for (const part of relative.split('/')) {
      file.append(part);
    }

    if (!file.exists() || !file.isFile()) {
      // Missing file -> path + "\n" only (matches the C installer).
      continue;
    }

    const fis = Cc['@mozilla.org/network/file-input-stream;1'].createInstance(
      Ci.nsIFileInputStream
    );
    fis.init(file, 0x01, 0o444, 0);
    binStream.setInputStream(fis);
    const count = fis.available();
    const data = new ArrayBuffer(count);
    binStream.readArrayBuffer(count, data);
    hasher.update(new Uint8Array(data), count);
    fis.close();
  }

  const base64 = hasher.finish(true);
  const binary = atob(base64);
  let hex = '';
  for (let i = 0; i < binary.length; i++) {
    hex += binary.charCodeAt(i).toString(16).padStart(2, '0');
  }
  return hex;
}

/* ---------------- zip helpers (shared with the updater tab engine) ---------------- */

/**
 * Hash the manifest-listed files straight from a zip archive, WITHOUT
 * extracting it first (matches computeFilesHash semantics: sorted rel paths,
 * path + '\n' then contents; missing entries contribute path + '\n' only).
 * Handles a single top-level wrapper folder the same way extractZipFlatten
 * flattens it, so a tampered archive is rejected before a single byte is
 * written anywhere.
 *
 * @returns {Promise<string>} hex sha256
 */
export async function computeZipFilesHash(files, zipPath) {
  const zipFile = await IOUtils.getFile(zipPath);
  const zipReader = Cc['@mozilla.org/libjar/zip-reader;1'].createInstance(Ci.nsIZipReader);
  zipReader.open(zipFile);

  // Detect a single top-level wrapper folder (fx-folder.zip style): no files
  // at the archive root and exactly one top-level entry -> descend into it.
  let prefix = '';
  const tops = new Set();
  let hasRootFile = false;
  for (const name of zipReader.findEntries('*?*')) {
    if (name.includes('/')) {
      tops.add(name.split('/')[0]);
    } else {
      hasRootFile = true;
    }
  }
  if (!hasRootFile && tops.size === 1) {
    prefix = [...tops][0] + '/';
  }

  const sorted = [...files].sort((a, b) => a.localeCompare(b));
  const hasher = Cc['@mozilla.org/security/hash;1'].createInstance(Ci.nsICryptoHash);
  hasher.init(Ci.nsICryptoHash.SHA256);
  const encoder = new TextEncoder();

  for (const relative of sorted) {
    const pathBytes = encoder.encode(relative + '\n');
    hasher.update(pathBytes, pathBytes.length);
    const entryName = prefix + relative;
    if (!zipReader.hasEntry(entryName)) continue; // missing -> path + '\n' only
    const bytes = await readZipEntry(zipReader, entryName);
    hasher.update(bytes, bytes.length);
  }
  zipReader.close();

  const base64 = hasher.finish(true);
  const binary = atob(base64);
  let hex = '';
  for (let i = 0; i < binary.length; i++) {
    hex += binary.charCodeAt(i).toString(16).padStart(2, '0');
  }
  return hex;
}

/** Read a zip entry fully. @returns {Promise<Uint8Array>} */
export function readZipEntry(zipReader, entryName) {
  return new Promise(resolve => {
    const input = zipReader.getInputStream(entryName);
    const bin = Cc['@mozilla.org/binaryinputstream;1'].createInstance(Ci.nsIBinaryInputStream);
    bin.setInputStream(input);
    const count = input.available();
    const data = new ArrayBuffer(count);
    bin.readArrayBuffer(count, data);
    input.close();
    resolve(new Uint8Array(data));
  });
}

/**
 * Extract a zip into destDir. Mirrors the installer's extract_zip_flatten(): if
 * the archive has a single top-level folder (fx-folder.zip wraps files under
 * 'fx-folder/'), descend into it so files land flat.
 *
 * @returns {Promise<string>} the base dir containing the extracted files
 */
/**
 * Reject zip entry names that could escape destDir: absolute paths, Windows
 * backslash separators, drive-letter tricks, and '.'/'..' components. Zip entry
 * names always use '/', so anything else is an attack.
 */
function isUnsafeZipEntryName(entryName) {
  if (!entryName || entryName.startsWith('/') || entryName.includes('\\')) return true;
  const parts = entryName.split('/').filter(Boolean);
  for (const part of parts) {
    if (part === '.' || part === '..' || /^[a-zA-Z]:/.test(part)) return true;
  }
  return false;
}

export async function extractZipFlatten(zipPath, destDir) {
  await IOUtils.makeDirectory(destDir, {ignoreExisting: true, createAncestors: true});

  const zipFile = await IOUtils.getFile(zipPath);
  const zipReader = Cc['@mozilla.org/libjar/zip-reader;1'].createInstance(Ci.nsIZipReader);
  zipReader.open(zipFile);

  const entries = zipReader.findEntries('*?*');
  for (const entryName of entries) {
    // Zip-slip guard: never let an entry write outside destDir.
    if (isUnsafeZipEntryName(entryName)) {
      zipReader.close();
      throw new Error(`Unsafe zip entry name: ${entryName}`);
    }
    const entry = zipReader.getEntry(entryName);
    if (entry.isDirectory) {
      const dirPath = PathUtils.join(destDir, ...entryName.split('/').filter(Boolean));
      await IOUtils.makeDirectory(dirPath, {ignoreExisting: true, createAncestors: true});
    } else {
      const parts = entryName.split('/').filter(Boolean);
      const targetPath = PathUtils.join(destDir, ...parts);
      await IOUtils.makeDirectory(PathUtils.parent(targetPath), {
        ignoreExisting: true,
        createAncestors: true,
      });
      const bytes = await readZipEntry(zipReader, entryName);
      await IOUtils.write(targetPath, bytes, {tmpPath: targetPath + '.tmp'});
    }
  }
  zipReader.close();

  // Flatten a single top-level wrapper folder. IOUtils.getChildren returns
  // PATH STRINGS, not FileInfo objects — classify each child with
  // IOUtils.stat, whose FileInfo.type is 'regular' | 'directory' | 'other'
  // (there is no 'file' value). Without this the wrapper is never descended
  // into and the extracted files are missed (fx-folder.zip style).
  let base = destDir;
  for (let depth = 0; depth < 4; depth++) {
    const children = await IOUtils.getChildren(base);
    const stats = await Promise.all(children.map(c => IOUtils.stat(c).catch(() => null)));
    const subDirs = stats.filter(s => s && s.type === 'directory');
    const files = stats.filter(s => s && s.type === 'regular');
    if (files.length > 0) {
      break;
    }
    if (subDirs.length === 1) {
      base = subDirs[0].path;
      continue;
    }
    break;
  }
  return base;
}

/** Copy files listed in the manifest from srcDir to dstDir (overwrite). */
export async function copyFileList(files, srcDir, dstDir) {
  for (const rel of files) {
    if (isUnsafeZipEntryName(rel)) {
      throw new Error(`Unsafe manifest path: ${rel}`);
    }
    const parts = rel.split('/');
    const srcPath = PathUtils.join(srcDir, ...parts);
    const dstPath = PathUtils.join(dstDir, ...parts);
    await IOUtils.makeDirectory(PathUtils.parent(dstPath), {
      ignoreExisting: true,
      createAncestors: true,
    });
    await IOUtils.copy(srcPath, dstPath, {noOverwrite: false});
  }
}
